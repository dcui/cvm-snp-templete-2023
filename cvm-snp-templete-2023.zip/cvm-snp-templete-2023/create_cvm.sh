#!/usr/bin/bash

date
set -x
az account set --subscription "Linux Testing"

time=`date +%Y%m%d%H%M%S`
alias="decui"
deployName="$alias-ubuntu-snp-cvm-"$time
resourceGroup="$alias-ubuntu-snp-cvm-"$time
vmName="$alias-ubuntu-snp-cvm-"$time

az group create --name $resourceGroup --location "westus" || exit -1
az deployment group create -g $resourceGroup -n $deployName -f ./deployCPSCVM_customVHD.json -p ./azuredeploy.parameters.sample.json -p vmName=$vmName

echo result is: $?
set +x
date
